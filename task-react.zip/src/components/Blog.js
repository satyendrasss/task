import Layout from "../layouts/Layout";
import React, { useEffect, useState } from "react";

function Blog() {

    const [blogs, setBlogs] = useState([]);
    useEffect(() => {
        getBlog();
    }, []);
    // async function getBlog() {
    const getBlog = async () => {
        // console.warn('Blog Loaded'); .
        try {
            const response = await fetch('http://localhost:4000/api/blog');
            const data = await response.json();
            // console.log(data);
            setBlogs(data.result);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    }

    return (
        <>
            <Layout>
                <h1 >Blog Page</h1>
                {blogs.map((blog) => (
                    <div className="d-flex p-2" key={blog._id}>
                        <div className="p-2 bg-info">
                            <b>{blog.title}</b>
                            <p>{blog.short_desc}</p>
                        </div>
                    </div>
                ))}
            </Layout>
        </>
    )
}

export default Blog;