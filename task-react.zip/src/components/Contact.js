import Layout from "../layouts/Layout";
import { useState } from "react";
function Contact() {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");
    const [file, setFile] = useState("");
    async function AddContactForm(e){
        e.preventDefault();
        try {
            // console.warn(name,email, message, file);
            const formData = new FormData();
            formData.append('name',name);
            formData.append('email',email);
            formData.append('message',message);
            formData.append('document',file);

            let headers = new Headers();

            // headers.append('Content-Type', 'application/json');
            // headers.append('Accept', 'application/json');
            // headers.append('Authorization', 'Basic ' + base64.encode(username + ":" +  password));
            // headers.append('Origin','http://localhost:3000');

            //console.log(formData);

            let res = await fetch("http://localhost:4000/api/contact", {
                method: "POST",
                // body: JSON.stringify({
                //   name: name,
                //   email: email,
                //   mobileNumber: mobileNumber,
                // }),
                body:formData,
                // mode: 'cors',
                headers:headers
            });
            let resJson = await res.json();
            if (resJson.status === 200) {
                // setName("");
                // setEmail("");
                console.warn('success');
            } else {
                console.warn("Some error occured");
            }
        }catch (err) {
            console.log(err);
        }

    }
    

    return (
        <>
            <Layout>
                <h1>Contact Form</h1>
                {/* <form> */}
                    <div className="mb-3 mt-3">
                        <label className="form-label">Name:</label>
                        <input type="text" className="form-control" onChange={(e)=>setName(e.target.value)} placeholder="Enter name" />
                    </div>
                    <div className="mb-3 mt-3">
                        <label className="form-label">Email:</label>
                        <input type="email" className="form-control" onChange={(e)=>setEmail(e.target.value)} placeholder="Enter email" />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Message:</label>
                        <textarea className="form-control" onChange={(e)=>setMessage(e.target.value)} placeholder="Enter Meaage"></textarea>
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Document:</label>
                        <input type="file" className="form-control" onChange={(e)=>setFile(e.target.files[0])} />
                    </div>
                    
                    <button onClick={AddContactForm} className="btn btn-primary">Submit</button>
                {/* </form> */}
            </Layout>
        </>
    )
}
export default Contact;