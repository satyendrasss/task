import Layout from '../../layouts/Layout';
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom"; 


function Task()
{
    const [tasks, setTasks] = useState([]);
    useEffect(() => {
        getTask();
    }, []);
    // async function getBlog() {
    const getTask = async () => {
        // console.warn('Blog Loaded'); .
        try {
            const response = await fetch('http://127.0.0.1:8000/api/v1/task-list');
            const res = await response.json();
            console.log(res.data);
            setTasks(res.data);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    }

    return (
        <Layout>
            <h3>Task List</h3>
            <Link to='/add-task'><i className='fa fa-plus btn btn-primary sm float-end m-2'> Add Task</i></Link>
            <table className='table table-bordered'>
                <thead>
                    <tr>
                        <th>User Details</th>
                        <th>Title</th>
                        {/* <th>Assign</th> */}
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {tasks.map((task)=>(
                        <tr>
                            <td>{task.user.name}</td>
                            <td>{task.title}</td>
                            {/* <td>{task.created_at}</td> */}
                            <td>{task.deadline}</td>
                            <td>
                                <span className='badge bg-success'>{task.status}</span>
                            </td>
                            <td>
                            <Link to={`/task-details/${task.id}`} className='m-1'>
                                <span className='badge bg-primary'> <i className="fa fa-eye" aria-hidden="true"></i></span>
                            </Link>
                            <Link to={`/task-edit/${task.id}`} className='m-1'>
                                <span className='badge bg-primary'> <i className="fa fa-pencil" aria-hidden="true"></i></span>
                            </Link>
                            <Link to={`/task-details/${task.id}`}>
                                <span className='badge bg-danger'> <i className="fa fa-trash" aria-hidden="true"></i></span>
                            </Link>
                            </td>
                        </tr>
                    ))}
                    
                </tbody>
            </table>
        </Layout>
    )
}
export default Task;