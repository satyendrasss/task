import Layout from "../../layouts/Layout";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function TaskDetails()
{
    const [task, setTask] = useState([]);
    const { id } = useParams();
    useEffect(() => {
        getTask();
    }, []);
    // async function getBlog() {
    const getTask = async () => {
        // console.warn('Blog Loaded'); .
        try {
            const response = await fetch('http://127.0.0.1:8000/api/v1/task-details/'+id);
            const res = await response.json();
            console.log(res.data);
            setTask(res.data);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    }

    return (
        <Layout>
            <h1>Task details</h1>
            <div className="col-sm-12">
                <h3>{task.title}</h3>
                <p>
                    <span> <i className="fa fa-calendar"></i> {task.created_at}</span>
                    <span> Deadline: {task.deadline}</span>
                </p>
                <p>{task.description}</p>
            </div>
        </Layout>
    )
}

export default TaskDetails;