import Layout from "../../layouts/Layout";
import { useEffect, useState } from "react";
import { Navigate } from 'react-router-dom';

function AddTask() {
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [deadline, setDeadline] = useState("");
    const [userId, setUserId] = useState("");
    
    async function AddTaskForm(e){
        e.preventDefault();
        try {
            const formData = new FormData();
            formData.append('title',title);
            formData.append('description',description);
            formData.append('deadline',deadline);
            formData.append('user_id',userId);

            let headers = new Headers();
            let res = await fetch("http://127.0.0.1:8000/api/v1/task-save", {
                method: "POST",
                body:formData,
                headers:headers
            });
            let resJson = await res.json();
            console.log(resJson);
            if (resJson.success) {
                return <Navigate to='/task'/>;
                console.warn('success');
            } else {
                console.warn("Some error occured");
            }

        }catch (err) {
            console.log(err);
        }
    }


    const [users, setUsers] = useState([]);
    useEffect(() => {
        getUser();
    }, []);
    // async function getBlog() {
    const getUser = async () => {
        // console.warn('Blog Loaded'); .
        try {
            const response = await fetch('http://127.0.0.1:8000/api/v1/users');
            const res = await response.json();
            console.log(res.data);
            setUsers(res.data);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    }

    return (
        <Layout>
            <h3>Add Task</h3>
            <div className="mb-3 mt-3">
                <label className="form-label">Title:</label>
                <input type="text" className="form-control" onChange={(e) => setTitle(e.target.value)} placeholder="Enter name" />
            </div>
            <div className="mb-3">
                <label className="form-label">Description:</label>
                <textarea className="form-control" onChange={(e) => setDescription(e.target.value)} placeholder="Enter Meaage"></textarea>
            </div>
            <div className="row">
                <div className="mb-3 col-sm-6">
                    <label className="form-label">Deadline:</label>
                    <input type="date" className="form-control" onChange={(e) => setDeadline(e.target.value)} placeholder="Enter date" />
                </div>
                <div className="mb-3 col-sm-6">
                    <label className="form-label">User:</label>
                    <select className="form-control" onChange={(e)=>setUserId(e.target.value)}>
                        <option value="">Select User</option>
                        {users.map((user)=>(
                            <option key={user.id} value={user.id}>{user.name}</option>
                        ))

                        }
                    </select>
                </div>
            </div>

            <button onClick={AddTaskForm} className="btn btn-primary">Submit</button>
        </Layout>
    )
}
export default AddTask;