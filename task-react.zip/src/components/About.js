import React from 'react';
import Layout from '../layouts/Layout';

function About(){
    return ( 
        <Layout>
            <h1>About Page</h1>
        </Layout>
    )
}

export default About;