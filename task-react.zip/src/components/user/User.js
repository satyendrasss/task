import Layout from '../../layouts/Layout';
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom"; 

function User()
{
    const [users, setUsers] = useState([]);
    useEffect(() => {
        getUser();
    }, []);
    // async function getBlog() {
    const getUser = async () => {
        // console.warn('Blog Loaded'); .
        try {
            const response = await fetch('http://127.0.0.1:8000/api/v1/users');
            const res = await response.json();
            console.log(res.data);
            setUsers(res.data);
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    }

    return (
        <Layout>
            <h3>Users</h3>
            <Link to='/add-user'><i className='fa fa-plus btn btn-primary sm float-end m-2'> Add Task</i></Link>
            <table className='table table-bordered'>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user)=>(
                        <tr>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>
                            <Link to={`/task-details/${user.id}`}>
                                <span className='badge bg-primary'> <i className="fa fa-eye" aria-hidden="true"></i></span>
                            </Link>
                            </td>
                        </tr>
                    ))}
                    
                </tbody>
            </table>
        </Layout>
    )
}

export default User;