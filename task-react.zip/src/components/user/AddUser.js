import Layout from "../../layouts/Layout";
import { useEffect, useState } from "react";

function AddUser()
{
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    
    async function AddUserForm(e){
        e.preventDefault();
        try {
            const formData = new FormData();
            formData.append('name',name);
            formData.append('email',email);
            formData.append('password',password);

            let headers = new Headers();
            let res = await fetch("http://127.0.0.1:8000/api/v1/add-user", {
                method: "POST",
                body:formData,
                headers:headers
            });
            let resJson = await res.json();
            console.log(resJson);
            if (resJson.success) {
                console.warn('success');
            } else {
                console.warn("Some error occured");
            }


        }catch (err) {
            console.log(err);
        }
    }



    return (
        <Layout>
            <h3>Add User</h3>
            <div className="mb-3 mt-3">
                <label className="form-label">Name:</label>
                <input type="text" className="form-control" onChange={(e) => setName(e.target.value)} placeholder="Enter name" />
            </div>
            <div className="mb-3">
                <label className="form-label">Email:</label>
                <input className="form-control" onChange={(e) => setEmail(e.target.value)} placeholder="Enter Email"/>
            </div>
            <div className="row">
                <div className="mb-3 col-sm-12">
                    <label className="form-label">Password:</label>
                    <input type="password" className="form-control" onChange={(e) => setPassword(e.target.value)} placeholder="Enter Password" />
                </div>
                
            </div>

            <button onClick={AddUserForm} className="btn btn-primary">Submit</button>
        </Layout>
    )
}

export default AddUser;