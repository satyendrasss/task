import Layout from '../layouts/Layout';

function Home(){
    return ( 
        <Layout>
            <h1>Home Page</h1>
        </Layout>
    )
}

export default Home;