// import logo from './logo.svg';
import './App.css';
import Layout from './layouts/Layout';
import Home from './components/Home';
import About from './components/About';

import { Route, Routes } from 'react-router-dom';
import Contact from './components/Contact';
import Blog from './components/Blog';
import Task from './components/task/Task';
import TaskDetails from './components/task/TaskDetails';
import AddTask from './components/task/AddTask';
import User from './components/user/User';
import AddUser from './components/user/AddUser';
import TaskUpdate from './components/task/TaskUpdate';

function App() {
  return (
    <div className="App">
      <Routes>
         <Route path='/' element={<Home/>} />
         <Route path='/task' element={<Task/>} />
         <Route path='/add-task' element={ <AddTask/> } />
         <Route path='/task-details/:id' element={<TaskDetails/>} />
         <Route path='/task-edit/:id' element={<TaskUpdate/>} />

         <Route path='/user' element={ <User/> } />
         <Route path='/add-user' element={<AddUser/>} />
         <Route path='/about' element={<About/>} />
         <Route path='/contact' element={<Contact/>} />
         <Route path='/blog' element={<Blog/>} />
        
       </Routes>
    </div>
  );
}

export default App;
