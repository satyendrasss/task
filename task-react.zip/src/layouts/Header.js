import { Link } from "react-router-dom"; 

function Header(){
    return(
        <>
            <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
                <div className="container">
                    <a className="navbar-brand" href="#">Logo</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                    <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="collapsibleNavbar">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to="/">Home</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/user">Users</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/task">Task</Link>
                        </li>
                        {/* <li className="nav-item">
                            <Link className="nav-link" to="/about">About</Link>
                        </li>
                        <li className="nav-item">
                        <a className="nav-link" href="contact">Contact</a>
                        </li>  
                        <li className="nav-item">
                        <a className="nav-link" href="blog">Blog</a>
                        </li>   */}
                        
                        
                        {/* <li className="nav-item dropdown">
                        <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Setting</a>
                        <ul className="dropdown-menu">
                            <li><a className="dropdown-item" href="#">User Management</a></li>
                            <li><a className="dropdown-item" href="#">All Contact</a></li>
                            <li><a className="dropdown-item" href="#">A third link</a></li>
                        </ul>
                        </li> */}
                        
                    </ul>
                    </div>
                    <div>
                        {/* <ul className="navbar-nav">
                            <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">sss</a>
                            <ul className="dropdown-menu">
                                <li><a className="dropdown-item" href="#">Link</a></li>
                                <li><a className="dropdown-item" href="#">Another link</a></li>
                                <li><a className="dropdown-item" href="logout">Logout</a></li>
                            </ul>
                            </li>
                        </ul> */}
                    </div>
                </div>
            </nav>
        </>
    )
}
export default Header;