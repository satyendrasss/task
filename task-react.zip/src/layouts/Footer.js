function Footer(){
    return(
        <>
            <footer>
                <nav className="navbar navbar-expand-sm border bg-secondary justify-content-center">
                <ul className="navbar-nav">
                    <li className="nav-item">
                    <a className="nav-link" href="#">Task Management System</a>
                    </li>
                </ul>
                </nav>
            </footer>

            {/* <script src="assets/js/jquery.min.js"></script> */}
        </>
    )
}
export default Footer;