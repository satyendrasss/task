<h1>
    Test
</h1>

@php
    //print_r($tasks);
@endphp

@foreach($tasks as $tsk)
    <p>{{$tsk->user->name}} :-) {{$tsk->title}}  </p>
@endforeach