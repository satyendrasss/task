<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\UserRequest;
use Hash;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function addUser(UserRequest $request)
    {
        $req = $request->all();
        //$hashPassword = hash('sha256',$request->input('password'));
        $userArr['name'] = $request->input('name');
        $userArr['email'] = $request->input('email');
        $userArr['password'] = Hash::make($request->input('password'));
        $res = User::create($userArr);
        return response()->json([
            'success' => true,
            'message' => 'User added successfully.'
        ]);
    }

    public function LoginUser(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);


        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            $userId = Auth::user()->id;
            $userInfo = User::find($userId,['id','name','email']);
            return response()->json([
                'success' => true,
                'message' => 'User login successfully.',
                'result' => $userInfo
            ]);
        }
    }

    public function allUser()
    {
        $users = User::where('role','User')->get(['id','name','email']);
        return response()->json([
            'success' => true,
            'data' => $users
        ]);
    }
}
