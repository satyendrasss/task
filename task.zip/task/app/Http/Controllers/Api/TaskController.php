<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\TaskRequest;
class TaskController extends Controller
{
    public function allTask()
    {
        $tasks = Task::all(['id','title','description','status','deadline','user_id','created_at'])->load('user');
        // $tasks = Task::with('user')->get();
        return response()->json([
            'success' => true,
            'data' => $tasks
        ]);
    }

    public function saveTast(TaskRequest $request)
    {
        $req = $request->all();
        
        $res = Task::create($request->all());
        $user_id = $request->input('user_id');
        $userInfo = User::find($user_id);
        $userEmail = $userInfo['email'];
        // $data['email'] = 'satyendrasinghbca777@gmail.com';
        $data['email'] = $userEmail;
        dispatch(new \App\Jobs\SendEmailJob($data));

        return response()->json([
            'success' => true,
            'message' => 'Task added successfully.'
        ]);
    }

    public function editTask($id)
    {
        $task = Task::find($id);
        return response()->json([
            'success' => true,
            'message' => 'Data fetch successfully.',
            'data'=>$task
        ]);
    }

    public function showTask($id)
    {
        $task = Task::find($id)->load('user');
        return response()->json([
            'success' => true,
            'message' => 'Data fetch successfully.',
            'data'=>$task
        ]);
    }
    public function updateTask(TaskRequest $request)
    {
        $req = $request->all();
        $id = $req['id'];

        $reqArr = [
            'title' => $req['title'],
            'description' => $req['description'],
            'deadline' => $req['deadline'],
        ];
        $task = Task::find($id);
        $task->update($reqArr);
        return response()->json([
            'success' => true,
            'message' => 'Task updated successfully.'
        ]);
    }

}
