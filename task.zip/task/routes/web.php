<?php

use App\Http\Controllers\Api\TaskController;
use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController as TestController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('send-mail', function(){
    $data['email'] = 'satyendrasinghbca777@gmail.com';
    dispatch(new App\Jobs\SendEmailJob($data));
    dd('Email send successfully.');
});

Route::get('task-list', [TestController::class, 'allTask']);


Route::group(['prefix' => 'api/v1'], function () {
    //TASK
    Route::get('task-list', [TaskController::class, 'allTask']);
    Route::post('task-save',[TaskController::class, 'saveTast']);
    Route::get('task-edit/{id}',[TaskController::class,'editTask']);
    Route::get('task-details/{id}',[TaskController::class,'showTask']);
    Route::post('task-update',[TaskController::class,'updateTask']);
    Route::post('assign-task',[TaskController::class,'assignTask']);

    // User
    Route::post('add-user',[UserController::class, 'addUser']);
    Route::post('login',[UserController::class, 'LoginUser']);
    Route::get('users',[UserController::class,'allUser']);
});